const { Client, LocalAuth } = require('whatsapp-web.js')
const cheerio = require('cheerio')
const https = require('https')
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36'

function get(u, t = 15000) {
  return new Promise((resolve, reject) => {
    const req = https.get(u, { headers: { 'user-agent': UA } }, res => {
      if (res.statusCode !== 200) {
        reject(new Error('status code ' + res.statusCode))
        res.resume()
        return
      }
      let data = ''
      res.on('data', chunk => (data += chunk))
      res.on('end', () => resolve(data))
    })
    req.on('error', reject)
    req.setTimeout(t, () => {
      req.destroy()
      reject(new Error('timeout'))
    })
  })
}

async function search(q) {
  const $ = cheerio.load(await get('https://www.tudocelular.com/busca.php?q=' + encodeURIComponent(q)))
  const results = []
  $('li[itemprop="itemListElement"]').each((_, el) => {
    const a = $(el).find('a').first()
    const href = a.attr('href')
    const title = a.attr('title') || $(el).text().trim()
    if (href && title) {
      const url = href.startsWith('http') ? href : 'https://www.tudocelular.com' + href
      results.push({ title, url })
    }
  })
  results.sort((a, b) => {
    const aIsFicha = a.url.includes('/fichas-tecnicas/')
    const bIsFicha = b.url.includes('/fichas-tecnicas/')
    if (aIsFicha === bIsFicha) return 0
    return aIsFicha ? -1 : 1
  })
  return results
}

function normalizeKey(k) {
  return k.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s-]+/g, '_').toUpperCase()
}

async function info(url, query) {
  const $ = cheerio.load(await get(url))
  const data = {}
  if ($('.specs').length) {
    $('.specs tr').each((_, el) => {
      const key = $(el).find('th').text().trim()
      const val = $(el).find('td').text().trim()
      if (key) data[normalizeKey(key)] = val === '✓' ? true : val === '✗' ? false : val
    })
  }

  if (Object.keys(data).length === 0) {
    // fallback para sites alternativos (exemplo Magazineluiza)
    try {
      const html2 = await get('https://m.magazineluiza.com.br/busca/?q=' + encodeURIComponent(query))
      const $2 = cheerio.load(html2)
      const snippet = $2('div.ficha-tecnica').text().trim().slice(0, 800)
      data.FALLBACK = snippet || 'Ficha técnica não disponível'
    } catch {
      data.FALLBACK = 'Ficha técnica não disponível'
    }
  }

  // tenta pegar preço se existir
  const preco = $('a.best_price').first()
  if (preco.length) data.PRECO = { price: preco.text().trim(), url: preco.attr('href') }

  return data
}

function formatData(obj) {
  return Object.entries(obj)
    .map(([k, v]) => (typeof v === 'object' ? `${k}: ${v.price || JSON.stringify(v)}` : `${k}: ${v}`))
    .join('\n')
}

const client = new Client({ authStrategy: new LocalAuth() })

client.on('qr', qr => console.log('QR code recebido, escaneie com o WhatsApp:', qr))
client.on('ready', () => console.log('Bot pronto!'))
client.on('message', async message => {
  if (!message.body.toLowerCase().startsWith('.celular ')) return
  const query = message.body.slice(9).trim()
  try {
    const results = await search(query)
    if (results.length === 0) {
      await message.reply('Não encontrei nenhum resultado para esse celular.')
      return
    }
    const target = results.find(r => r.url.includes('/fichas-tecnicas/')) || results[0]
    const details = await info(target.url, query)
    const reply = formatData(details)
    for (let i = 0; i < reply.length; i += 3900) {
      await message.reply(reply.slice(i, i + 3900))
    }
  } catch {
    await message.reply('Ocorreu um erro ao buscar as informações. Tente novamente mais tarde.')
  }
})

client.initialize()